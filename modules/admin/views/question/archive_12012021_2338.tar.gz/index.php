<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Question */
?>
<div class="question-view">
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'question',
            'question_1',
            'question_2',
            'question_3',
            'question_4',
            'question_5',
            'question_6',
            'question_7',
            'question_8',
            'question_9',
            'question_10',
            'question_11',
            'question_12',
            'question_13',
            'question_14',
            'question_15',
        ],
    ]) ?>

</div>
